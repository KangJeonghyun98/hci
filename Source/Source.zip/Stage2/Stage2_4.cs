using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Leap;
using Leap.Unity;

public class Stage2_4 : MonoBehaviour
{
    Controller controller;
    public GameObject waste;


    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        controller = new Controller();
        Frame frame = controller.Frame();
        List<Hand> hands = frame.Hands;
        List<Finger> fingers = hands[0].Fingers;

        //Debug.Log(fingers[1].IsExtended);
        
        if (controller.IsConnected){
            this.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);
            }
            else this.transform.position = new Vector3(0, 0, 0);

        waste.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);

        if (hands[0].PalmVelocity.z < -2500){
            SpriteRenderer spriteR = waste.GetComponent<SpriteRenderer>();
	        Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/stage2");
	        spriteR.sprite = sprites[0];
            Invoke("Scenechange", 3);
        }
        
    }
    void Scenechange(){
        SceneManager.LoadScene("Stage2_2");
    }
    
}