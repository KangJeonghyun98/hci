using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Leap;
using Leap.Unity;

public class Stage4_4 : MonoBehaviour
{
    Controller controller;
    public GameObject cutter;
    public GameObject closed;
    public GameObject tape;

    int flag = 0;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        controller = new Controller();
        Frame frame = controller.Frame();
        List<Hand> hands = frame.Hands;
        List<Finger> fingers = hands[0].Fingers;

        //Debug.Log(fingers[1].IsExtended);
        
        if (controller.IsConnected){
            this.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);
            }
            else this.transform.position = new Vector3(0, 0, 0);
        
        if (fingers[1].IsExtended == false &
            fingers[2].IsExtended == false &
            fingers[3].IsExtended == false){
                SpriteRenderer spriteR = gameObject.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/hand");
	            spriteR.sprite = sprites[0];
            }
        else {
            SpriteRenderer spriteR = gameObject.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/hand");
	            spriteR.sprite = sprites[1];
        }
        
        if (this.transform.position.y > cutter.transform.position.y - 0.5f &
            this.transform.position.y < cutter.transform.position.y + 0.5f &
            this.transform.position.x > cutter.transform.position.x - 0.5f &
            this.transform.position.x < cutter.transform.position.x + 0.5f &
            fingers[1].IsExtended == false){
                    cutter.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);
                }
        
        if (closed.transform.position.y > cutter.transform.position.y - 1.0f &
            closed.transform.position.y < cutter.transform.position.y + 1.0f &
            closed.transform.position.x > cutter.transform.position.x - 1.0f &
            closed.transform.position.x < cutter.transform.position.x + 1.0f &
            fingers[1].IsExtended == true){
                SpriteRenderer spriteR = closed.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/stage4");
	            spriteR.sprite = sprites[0];
                
                if (flag == 0){
                    Invoke("Tape", 0.01f);
                }
                Invoke("Scenechange", 5);
            }
    }
        
    void Scenechange(){
        SceneManager.LoadScene("Stage4_2");
    }

    void Tape(){
        Instantiate(tape, new Vector3 (0.8f, -1.6f, 0), Quaternion.identity);
        flag = 1;
    }
}