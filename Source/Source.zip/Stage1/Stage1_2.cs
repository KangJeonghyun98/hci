using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Leap;
using Leap.Unity;
using UnityEngine.SceneManagement;

public class Stage1_2 : MonoBehaviour
{
    Controller controller;
    public GameObject bin1;
    public GameObject bin2;
    public GameObject bin3;
    public GameObject bin4;
    public GameObject empty;
    

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        controller = new Controller();
        Frame frame = controller.Frame();
        List<Hand> hands = frame.Hands;
        List<Finger> fingers = hands[0].Fingers;
        
        if (controller.IsConnected){
            this.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);
            }
        else this.transform.position = new Vector3(0, 0, 0);

        if (fingers[1].IsExtended == false &
            fingers[2].IsExtended == false &
            fingers[3].IsExtended == false){
                SpriteRenderer spriteR = gameObject.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/hand");
	            spriteR.sprite = sprites[0];
            }
        else {
            SpriteRenderer spriteR = gameObject.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/hand");
	            spriteR.sprite = sprites[1];
        }

        if (this.transform.position.y > empty.transform.position.y - 1.5f &
            this.transform.position.y < empty.transform.position.y + 1.5f &
            this.transform.position.x > empty.transform.position.x - 1.5f &
            this.transform.position.x < empty.transform.position.x + 1.5f &
            fingers[1].IsExtended == false){
                    empty.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);
                }

        if (bin4.transform.position.y > empty.transform.position.y - 1.5f &
            bin4.transform.position.y < empty.transform.position.y + 1.5f &
            bin4.transform.position.x > empty.transform.position.x - 1.5f &
            bin4.transform.position.x < empty.transform.position.x + 1.5f &
            fingers[1].IsExtended == true){
                Invoke("Scenechange", 0.01f);
            }
    
        if (bin1.transform.position.y > empty.transform.position.y - 1.0f &
            bin1.transform.position.y < empty.transform.position.y + 1.0f &
            bin1.transform.position.x > empty.transform.position.x - 1.0f &
            bin1.transform.position.x < empty.transform.position.x + 1.0f &
            fingers[1].IsExtended == true){
                SceneManager.LoadScene("Stage1_wrong2");
            }

        if (bin2.transform.position.y > empty.transform.position.y - 1.0f &
            bin2.transform.position.y < empty.transform.position.y + 1.0f &
            bin2.transform.position.x > empty.transform.position.x - 1.0f &
            bin2.transform.position.x < empty.transform.position.x + 1.0f &
            fingers[1].IsExtended == true){
                SceneManager.LoadScene("Stage1_wrong2");
            }

        if (bin3.transform.position.y > empty.transform.position.y - 1.0f &
            bin3.transform.position.y < empty.transform.position.y + 1.0f &
            bin3.transform.position.x > empty.transform.position.x - 1.0f &
            bin3.transform.position.x < empty.transform.position.x + 1.0f &
            fingers[1].IsExtended == true){
                SceneManager.LoadScene("Stage1_wrong2");
            }
    }

    void Scenechange(){
        SceneManager.LoadScene("Stage1_3");
    }
}


