using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Leap;
using Leap.Unity;

public class Stage5_4 : MonoBehaviour
{
    Controller controller;
    public GameObject gas;
    public GameObject smoke;
    int flag = 0;
    

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        controller = new Controller();
        Frame frame = controller.Frame();
        List<Hand> hands = frame.Hands;
        List<Finger> fingers = hands[0].Fingers;

        //Debug.Log(fingers[1].IsExtended);
        
        if (controller.IsConnected){
            this.transform.position = new Vector3(hands[0].PalmPosition[0] / 30, -hands[0].PalmPosition[2] / 30, 0);
            }
            else this.transform.position = new Vector3(0, 0, 0);
        
        if (fingers[1].IsExtended == true &
            fingers[2].IsExtended == false &
            fingers[3].IsExtended == false) {
                SpriteRenderer spriteR = gameObject.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/stage5");
	            spriteR.sprite = sprites[0];
            }
        else {
            SpriteRenderer spriteR = gameObject.GetComponent<SpriteRenderer>();
	            Sprite[] sprites = Resources.LoadAll<Sprite>("Sprites/hand");
	            spriteR.sprite = sprites[1];
        }
        
        if (this.transform.position.y > gas.transform.position.y - 1.0f &
            this.transform.position.y < gas.transform.position.y + 1.0f &
            this.transform.position.x > gas.transform.position.x - 1.0f &
            this.transform.position.x < gas.transform.position.x + 1.0f){
                if (flag == 0){
                    Invoke("Smoke", 0.01f);
                }
                Invoke("Scenechange", 1);
            }
        
    }
    void Scenechange(){
        SceneManager.LoadScene("Stage5_2");
    }

    void Smoke(){
        Instantiate(smoke, new Vector3 (-2.0f, -0.02f, 0), Quaternion.identity);
        flag = 1;
    }
    
}